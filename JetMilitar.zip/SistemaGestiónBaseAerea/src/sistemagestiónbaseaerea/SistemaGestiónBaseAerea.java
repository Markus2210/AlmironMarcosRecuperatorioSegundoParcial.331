/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestiónbaseaerea;

import config.RutaArchivos;
import java.util.List;
import model.Almacenable;
import model.Inventario;
import model.JetMilitar;
import model.TipoJet;

/**
 *
 * @author alumno
 */
public class SistemaGestiónBaseAerea {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Almacenable<JetMilitar> inv = new Inventario<>();
            inv.agregar(new JetMilitar(1, "F-16C", 950.5, 60,
                    2014, TipoJet.INTERCEPTOR));
            inv.agregar(new JetMilitar(2, "F-18E Super Hornet",
                    1200.2, 35, 2017, TipoJet.MULTIPROPOSITO));
            inv.agregar(new JetMilitar(3, "Mirage 2000", 800.0,
                    25, 2010, TipoJet.INTERCEPTOR));
            inv.agregar(new JetMilitar(4, "A-10 Thunderbolt", 1400.7,
                    70, 2012, TipoJet.ATAQUE));
            inv.agregar(new JetMilitar(5, "T-38 Talon", 600.0,
                    50, 2018, TipoJet.ENTRENAMIENTO));
            inv.agregar(new JetMilitar(6, "Gripen NG", 700.3,
                    15, 2020, TipoJet.RECONOCIMIENTO));
            System.out.println("=== Inventario original ===");
            for (JetMilitar j : inv.obtenerTodos()) {
                System.out.println(j);
            }
            // 1) Orden natural
            inv.ordenar();
            // 2) Ordenar por modelo
            inv.ordenar((d1, d2) -> d1.getModelo().compareTo(d2.getModelo()));
            // 3) Filtrar jets con nivelCombustible < 20
            List<JetMilitar> criticos
                    = inv.filtrar(v -> v.getNivelCombustible() < 20);
            // 4) Transformar ENTRENAMIENTO: +15% horasVuelo
            List<JetMilitar> transformados
                    = inv.transformar(d -> {
                        int horas = (int) (d.getHorasVuelo() * 0.85);
                        return new JetMilitar(d.getId(),
                                d.getModelo(),
                                horas,
                                d.getNivelCombustible(),
                                d.getAnioIngreso(),
                                TipoJet.ENTRENAMIENTO
                        );

                    });
            // 5) Contar ingresados antes de 2015
            int antiguos = inv.contar(d -> d.getAnioIngreso() > 2015);
            // Persistencias
            inv.guardarEnBinario(RutaArchivos.getRutaBINString());
            inv.guardarEnCSV(RutaArchivos.getRutaCSVString());
            inv.guardarEnJSON(RutaArchivos.getRutaJSONString());
            // Cargar desde CSV
            Almacenable<JetMilitar> invCSV = new Inventario<>();
            invCSV.cargarDesdeCSV(RutaArchivos.getRutaCSVString(), JetMilitar::fromCSV);
            System.out.println("\n=== Inventario cargado desde CSV ===");
            for (JetMilitar j : invCSV.obtenerTodos()) {
                System.out.println(j);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());

        }
    }
}
