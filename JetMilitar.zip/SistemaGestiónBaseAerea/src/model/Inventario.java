/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author alumno
 * @param <T>
 */
public class Inventario<T extends AeronaveMilitar> implements Almacenable<T> {

    private List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento nulo");
        lista.add(elemento);

    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        lista.removeIf(criterio);
    }

    @Override
    public List<T> obtenerTodos() {
        List<T> toReTurn = new ArrayList<>();
        for (T item : lista) {
            toReTurn.add(item);
        }
        return toReTurn;
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        T buscado = null;
        for (T item : lista) {
            if (criterio.test(item)) {
                buscado = item;
            }
        }
        return buscado;
    }

    @Override
    public void ordenar() {
        lista.sort((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        lista.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrada = new ArrayList<>();
        for (T item : lista) {
            if (criterio.test(item)) {
                filtrada.add(item);
            }
        }
        return filtrada;

    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> transforamada = new ArrayList<>();
        for (T item : lista) {
            transforamada.add(operador.apply(item));
        }
        return transforamada;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (T item : lista) {
            if (criterio.test(item)) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(ruta))) {
            serializador.writeObject(lista);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        lista.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) desearializador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            for (T item : lista) {
                escritor.write(item.toCSV());
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        lista.clear();
        AeronaveMilitar.toHeaderCSV();
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                lista.add(fromCSV.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try (FileWriter writer = new FileWriter(ruta)) {
            gson.toJson(lista, writer);
        } catch (IOException ex) {
            throw new Exception("Error al guardar en JSON: " + ex.getMessage());
        }
    }

    public void cargarDesdeJSON(String ruta) throws Exception {
        lista.clear();

        Type typeOfT = new TypeToken<List<T>>() {
        }.getType();

        Gson gson = new Gson();

        try (BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            List<T> listaCargada = gson.fromJson(reader, typeOfT);

            if (listaCargada != null) {
                lista = listaCargada;
            }

        }
    }

}
