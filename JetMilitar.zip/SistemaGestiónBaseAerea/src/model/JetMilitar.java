/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author alumno
 */
public class JetMilitar extends AeronaveMilitar{
    private TipoJet tipo;

    public JetMilitar(int id, String modelo, double horasVuelo, int nivelCombustible, int anioIngreso, TipoJet tipo) {
        super(id, modelo, horasVuelo, nivelCombustible, anioIngreso);
        this.tipo = tipo;
    }

    @Override
    public int compareTo(AeronaveMilitar o) {
        int resutadoFabricacion = ((int)o.getHorasVuelo()) - ((int)getHorasVuelo());

        if (resutadoFabricacion != 0) {
            return resutadoFabricacion;
        }
        return Integer.compare(o.getNivelCombustible(), getNivelCombustible());

    }
        public static JetMilitar fromCSV(String linea) {
        linea = linea.substring(0, linea.length());
        String[] datos = linea.split(",");
        return new JetMilitar(Integer.parseInt(datos[0]), datos[1], Double.parseDouble(datos[2]) , Integer.parseInt(datos[3]), Integer.parseInt(datos[4]), TipoJet.valueOf(datos[5]));
    }

    @Override
    public String getTipoCSV() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    
    
}
