/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author alumno
 */
public abstract class AeronaveMilitar implements Serializable, Comparable<AeronaveMilitar> {

    private int id;
    private String modelo;
    private double horasVuelo;
    private int nivelCombustible;
    private int anioIngreso;

    public AeronaveMilitar(int id, String modelo, double horasVuelo, int nivelCombustible, int anioIngreso) {
        this.id = id;
        this.modelo = modelo;
        this.horasVuelo = horasVuelo;
        this.nivelCombustible = nivelCombustible;
        this.anioIngreso = anioIngreso;

    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public double getHorasVuelo() {
        return horasVuelo;
    }

    public int getNivelCombustible() {
        return nivelCombustible;
    }

    public int getAnioIngreso() {
        return anioIngreso;
    }

    @Override
    public String toString() {
        return "AeronaveMilitar -> " + "id: " + id + " | modelo: " + modelo + " | horasVuelo: " + horasVuelo + " | nivelCombustible: " + nivelCombustible + " | anioIngreso: " + anioIngreso;
    }

    @Override
    public int compareTo(AeronaveMilitar o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String toCSV() {
        return id + "," + modelo + "," + horasVuelo + "," + nivelCombustible + "," + anioIngreso + "\n";
        }

    public static String toHeaderCSV() {
        return "id,modelo,horasDeVuelo,nivelCombustible,anioIngreso\n";
    }
        
    public abstract String getTipoCSV();

}
