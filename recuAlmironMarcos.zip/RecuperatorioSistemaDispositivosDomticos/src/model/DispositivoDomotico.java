/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class DispositivoDomotico implements CSVConvertible, Comparable<DispositivoDomotico> {

    private int codigo;
    private String nombreModelo;
    private Categoria categoria;
    private int consumoWatts;
    private int anioFabricacion;

    public DispositivoDomotico(int codigo, String nombreModelo, Categoria categoria, int consumoWatts, int anioFabricacion) {
        this.codigo = codigo;
        this.nombreModelo = nombreModelo;
        this.categoria = categoria;
        this.consumoWatts = consumoWatts;
        this.anioFabricacion = anioFabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getConsumoWatts() {
        return consumoWatts;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    @Override
    public int compareTo(DispositivoDomotico o) {
        int resutadoFabricacion = o.getAnioFabricacion() - getAnioFabricacion();

        if (resutadoFabricacion != 0) {
            return resutadoFabricacion;
        }
        return Integer.compare(getConsumoWatts(), o.getConsumoWatts());
    }

    @Override
    public String toCSV() {
        return codigo + "," + nombreModelo + "," + categoria + "," + consumoWatts + "," + anioFabricacion + "\n";
    }

    public static String toHeaderCSV() {
        return "codig,nombre,categoria,consumo,anioFabricacion\n";
    }

    public static DispositivoDomotico fromCSV(String linea) {
        linea = linea.substring(0, linea.length());
        String[] datos = linea.split(",");
        return new DispositivoDomotico(Integer.parseInt(datos[0]), datos[1], Categoria.valueOf(datos[2]), Integer.parseInt(datos[3]), Integer.parseInt(datos[4]));
    }

    @Override
    public String toString() {
        return "DispositivoDomotico ->" + "codigo: " + codigo + " | nombreModelo: " + nombreModelo + " | categoria: " + categoria + " | consumoWatts: " + consumoWatts + " | anioFabricacion: " + anioFabricacion;
    }

}
